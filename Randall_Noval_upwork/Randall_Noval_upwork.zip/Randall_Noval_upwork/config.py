csv_file = 'cards-sample.csv' # fixed for repo
github_username = 'randynov' # fixed for repo
github_repo_name = 'mtgmanager2aetherhub' # fixed for repo

branch_github_user_name = 'tekin7' # The name of the account that will make a pull request example(tekin7 my github account name)
branch_name='main' # branch name. change, if change your github account branch
password= '' # The pasword of the account that will make a pull request
github_token = '99ed0a5026f0c826d16e7ee554cb248c2ae3f630' #  The token of the account that will make a pull request

message = "Update cards-sample" # commit and pull request message